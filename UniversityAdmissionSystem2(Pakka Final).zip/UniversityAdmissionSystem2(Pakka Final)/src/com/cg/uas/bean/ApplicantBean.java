package com.cg.uas.bean;

import java.sql.Date;
import java.time.LocalDate;

public class ApplicantBean {

	private int appId;
	private	String fullName;
	private LocalDate dateOfBirth;
	private String qualification;
	private float marks;
	private String goals;
	private String email;
	private String idate;//handling null date entry
	private String programName;//getting program name choosen
	public ApplicantBean(int appId, String fullName, LocalDate dateOfBirth, String qualification, float marks,
			String goals, String email, String idate, String scheduledProgId, String status, LocalDate interviewDate) {
		super();
		this.appId = appId;
		this.fullName = fullName;
		this.dateOfBirth = dateOfBirth;
		this.qualification = qualification;
		this.marks = marks;
		this.goals = goals;
		this.email = email;
		this.idate = idate;
		this.scheduledProgId = scheduledProgId;
		this.status = status;
		this.interviewDate = interviewDate;
	}

	public String getProgramName() {
		return programName;
	}

	public void setProgramName(String programName) {
		this.programName = programName;
	}

	@Override
	public String toString() {
		return "ApplicantBean [appId=" + appId + ", fullName=" + fullName
				+ ", dateOfBirth=" + dateOfBirth + ", qualification="
				+ qualification + ", marks=" + marks + ", goals=" + goals
				+ ", email=" + email + ", scheduledProgId=" + scheduledProgId
				+ ", status=" + status + ", interviewDate=" + interviewDate
				+ "]";
	}

	public ApplicantBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	private String scheduledProgId;
	private String status;
	private LocalDate interviewDate;
	
	public ApplicantBean(int appId,String fullName, LocalDate dateOfBirth, String qualification, float marks,
			String goals, String email, String scheduledProgId, String status, LocalDate interviewDate) {
		super();
		
		this.appId = appId;
		this.fullName = fullName;
		this.dateOfBirth = dateOfBirth;
		this.qualification = qualification;
		this.marks = marks;
		this.goals = goals;
		this.email = email;
		this.scheduledProgId = scheduledProgId;
		this.status = status;
		this.interviewDate = interviewDate;
	}
	
	public ApplicantBean(int appId, String fullName, String programName,  String status, LocalDate interviewDate) {
		this.appId = appId;
		this.fullName = fullName;
		this.programName = programName;
		this.status = status;
		this.interviewDate = interviewDate;
	}
	
	public ApplicantBean(int appId, String fullName, String programName,  String status, String idate) {
		this.appId = appId;
		this.fullName = fullName;
		this.programName = programName;
		this.status = status;
		this.idate = idate;
	}
	
	public String getIdate() {
		return idate;
	}

	public void setIdate(String idate) {
		this.idate = idate;
	}

	public int getAppId() {
		return appId;
	}
	public void setAppId(int appId) {
		this.appId = appId;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public float getMarks() {
		return marks;
	}
	public void setMarks(float marks) {
		this.marks = marks;
	}
	public String getGoals() {
		return goals;
	}
	public void setGoals(String goals) {
		this.goals = goals;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getScheduledProgId() {
		return scheduledProgId;
	}
	public void setScheduledProgId(String scheduledProgId) {
		this.scheduledProgId = scheduledProgId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public LocalDate getInterviewDate() {
		return interviewDate;
	}
	public void setInterviewDate(LocalDate interviewDate) {
		this.interviewDate = interviewDate;
	}
	
}

