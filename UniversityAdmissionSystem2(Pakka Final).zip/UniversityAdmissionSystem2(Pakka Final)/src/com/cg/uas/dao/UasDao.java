package com.cg.uas.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.bean.ProgramsOffered;
import com.cg.uas.bean.ProgramsScheduled;
import com.cg.uas.bean.Users;
import com.cg.uas.exception.UniversityException;

public interface UasDao {
	public List<ProgramsScheduled> getProgramsScheduled() throws UniversityException;
	public List<ProgramsOffered> getProgramsOffered() throws UniversityException;
	public int setNewApplicant(ApplicantBean app) throws UniversityException;
	public Users getUserCredentials(String user) throws UniversityException;
	public ArrayList<ApplicantBean> getApplicants(String column,String progId) throws UniversityException;
	public List<ApplicantBean> getAllApplicant() throws UniversityException;
	public int updateApplicationDetails(int appId, String status, LocalDate date) throws UniversityException;
	public int generateAppId() throws UniversityException;
	public int generateScheduledProgId() throws UniversityException;
	/*
	 * Shweta
	 * 
	 */
	public int addProgramScheduled(ProgramsScheduled ps) throws UniversityException;
	public int deleteProgramScheduled(int scheduledProgId) throws UniversityException;
	/*
	 * Vaibhav
	 * 
	 */
	public int addProgramsOffered(ProgramsOffered admin) throws UniversityException;
	public int updateProgramsOffered(ProgramsOffered admin) throws UniversityException;
	public int deleteProgramsOffered(String id) throws UniversityException;
}
