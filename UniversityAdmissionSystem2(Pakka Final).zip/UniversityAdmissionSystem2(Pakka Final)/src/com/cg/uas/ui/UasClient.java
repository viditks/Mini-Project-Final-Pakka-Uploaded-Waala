package com.cg.uas.ui;


import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.bean.ProgramsOffered;
import com.cg.uas.bean.ProgramsScheduled;
import com.cg.uas.bean.Users;
import com.cg.uas.exception.UniversityException;
import com.cg.uas.service.UasService;
import com.cg.uas.service.UasServiceImpl;

public class UasClient {

	static Scanner sc = null;
	static UasService uasSer= null;
	static ApplicantBean appBean = null;
	static Users users = null;
	static ProgramsScheduled progSch = null;

	public static void main(String [] args){

		sc = new Scanner(System.in);
		uasSer = new UasServiceImpl();
		users = new Users();
		progSch = new ProgramsScheduled();

		System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
		System.out.println("\tUniversity Admission System");
		System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");

		mainMenu();
	}

	private static void mainMenu() {

		while(true) {
			System.out.println();

			int choice = 0;
			System.out.println("1. Applicant");
			System.out.println("2. Mac");
			System.out.println("3. Administrator");
			System.out.println("4. Exit");

			message("Enter your choice");//display meaningful message

			choice = sc.nextInt();

			switch(choice) {
			case 1: Applicant();
			break;
			case 2: mac("mac");
			break;
			case 3: admin("admin");
			break;
			case 4: exit();
			break;
			default:
				System.out.println("Invalid Input");
			}
		}

	}

	private static void message(String msg) {

		System.out.println();
		System.out.println("**************************************************************");
		System.out.println("\t"+msg);
		System.out.println("**************************************************************");
	}

	private static void Applicant() {
		System.out.println();
		System.out.println("1. New Application");
		System.out.println("2. View Status");
		System.out.println("3. Go Back");

		message("Enter your choice");
		int choice = sc.nextInt();
		System.out.println();
		switch(choice){
		case 1: newApplicant();
		break;
		case 2: viewStatus();
		break;		
		case 3: mainMenu();
		break;
		default: System.out.println("Invalid Input!");
		break;
		}

	}

	private static void newApplicant() {

		List<ProgramsScheduled>  progList = new ArrayList<>();

		try {

			progList = uasSer.getProgramsScheduled();

			if(progList.size() > 0){
				System.out.println("Program Scheduled");
				System.out.println("-------------------------------------------------------------------------------------------------------------------");
				System.out.printf("%13s %13s %20s %20s %20s %20s","PROGRAM-ID", "PROGRAM-NAME", "LOCATION", "START-DATE", "END-DATE", "SESSION-PER-WEEK");
				System.out.println();
				System.out.println("-------------------------------------------------------------------------------------------------------------------");

				for(ProgramsScheduled p: progList){

					System.out.format("%13s %13s %20s %20s %20s %20d",p.getProgramId(), p.getProgramName(),p.getLocation(),p.getStartDate(),p.getEndDate(),p.getSessionPerWeek());
					System.out.println();
				} 

				message("Enter Program Id from above list");
				String choice = sc.next();

				if(uasSer.validProgramId(progList, choice)){
					setApplicationBean(choice);
				}
				else{
					message("Please choose from above program id only");
				}
			}
			else{
				message("No Programs Available. Please try again later!");
			}

		}
		catch (UniversityException e) {
			message(e.getMessage());
		}

	}

	private static void viewStatus() {

		ArrayList<ApplicantBean> applicantList = new ArrayList<ApplicantBean>();
		Iterator it = null;

		try {

			message("Enter Application Id");
			String appId = sc.next();

			if(uasSer.isInteger(appId)){

				applicantList = uasSer.getApplicants("application_id", appId);

				if(applicantList.size() > 0){

					it = applicantList.iterator();
					message("Aplicant Details");

					System.out.println("-------------------------------------------------------------------------------------------------------------------");
					System.out.printf("%13s %20s %20s %20s %30s","APPLICANT-ID", "APPLICANT-NAME", "PROGRAM-NAME", "STATUS", "INTERVIEW-DATE");
					System.out.println();
					System.out.println("-------------------------------------------------------------------------------------------------------------------");

					for(ApplicantBean ab : applicantList){

						System.out.format("%13s %20s %20s %20s",ab.getAppId(), ab.getFullName(), ab.getProgramName(),ab.getStatus());
						if(ab.getInterviewDate() != null){
							System.out.format("%30s",ab.getInterviewDate());
						}
						else{
							System.out.format("%30s",ab.getIdate());
						}
						System.out.println();
					}
				}
				else{
					message("No applicant prsent!");
				}
			}
		}
		catch (UniversityException e) {
			System.out.println(e.getMessage());
		}
	}

	private static void setApplicationBean(String scheduledId) {

		System.out.println("\nEnter your Full Name");
		sc.nextLine();
		String name = sc.nextLine();

		System.out.println("Enter Date of Birth in format yyyy-mm-dd");
		String date = sc.next();
		System.out.println("Enter Highest Qualification");
		sc.nextLine();
		String qua = sc.nextLine();

		System.out.println("Enter Marks Obtained");
		Float marks = sc.nextFloat();

		System.out.println("Enter Goals");
		sc.nextLine();
		String goals = sc.nextLine();

		System.out.println("Enter Email Id");
		String email = sc.next();

		String status = "Applied";
		String interviewDate = null;

		LocalDate dob = LocalDate.parse(date);

		appBean = new ApplicantBean();
		appBean.setFullName(name);
		appBean.setDateOfBirth(dob);
		appBean.setQualification(qua);
		appBean.setMarks(marks);
		appBean.setGoals(goals);
		appBean.setEmail(email);
		appBean.setStatus(status);
		appBean.setScheduledProgId(scheduledId);

		try {
			if(uasSer.isValid(appBean)) {
				int applicantId = uasSer.setNewApplicant(appBean);
				if(applicantId > 0) {
					message("Thank You "+name + ". You have successfully registered to our program. Your unique id is "+ applicantId);
				}
			}
		}
		catch (UniversityException e) {
			message(e.getMessage());
		}
	}



	private static void mac(String user) {

		System.out.println("***********************************");
		System.out.println("Enter Login Id:");
		String loginId = sc.next();
		System.out.println("Enter Password: ");
		String password = sc.next();
		System.out.println("***********************************");

		try {

			if(uasSer.isString(loginId) && uasSer.isString(password)){

				if(uasSer.validateUser(loginId, password, user)) {

					while(true) {

						System.out.println("******************************");
						System.out.println("1. View Applications");
						System.out.println("2. Filter Applicants");
						System.out.println("3. Main Menu");
						System.out.println("4. Exit");

						message("Enter your choice");
						int choice = sc.nextInt();

						switch(choice) {
						case 1: viewApplications();
						break;
						case 2: filterApplicant();
						break;
						case 3: mainMenu();;
						break;
						case 4: exit();
						break;
						default: message("Invalid Input!");
						break;

						}
					}
				}
				else {
					message("Credentials Fails");
				}
			}
		}
		catch (UniversityException e) {
			message(e.getMessage());
		}

	}

	private static void viewApplications() {

		viewProgramsScheduled();

		message("Enter Program Scheduled Id");
		String pgId = sc.next();

		ArrayList<ApplicantBean> applicantList = new ArrayList<ApplicantBean>();
		try {

			if(uasSer.isInteger(pgId)){
				applicantList = uasSer.getApplicants("scheduled_program_id", pgId);
				if(applicantList.size() >0) {

					message("Aplicant Details");

					System.out.println("-------------------------------------------------------------------------------------------------------------------");
					System.out.printf("%13s %20s %20s %20s %30s","APPLICANT-ID", "APPLICANT-NAME", "PROGRAM-NAME", "STATUS", "INTERVIEW-DATE");
					System.out.println();
					System.out.println("-------------------------------------------------------------------------------------------------------------------");

					for(ApplicantBean ab : applicantList){

						System.out.format("%13s %20s %20s %20s",ab.getAppId(), ab.getFullName(), ab.getProgramName(),ab.getStatus());
						if(ab.getInterviewDate() != null){
							System.out.format("%30s",ab.getInterviewDate());
						}
						else{
							System.out.format("%30s",ab.getIdate());
						}
						System.out.println();
					}
				}
				else{
					message("No applicant exist!");
				}
			}


		}
		catch (UniversityException e) {
			message(e.getMessage());
		}

	}

	private static void filterApplicant() {

		ArrayList<ApplicantBean> applicantList = new ArrayList<ApplicantBean>();
		Iterator it = null;
		String appId = null;
		try {

			if(getAllApplicant()){

				message("Enter applicant id to update the details of applicant");
				appId = sc.next();

				if(uasSer.isInteger(appId)){

					applicantList = uasSer.getApplicants("application_id", appId);
					it = applicantList.iterator();

					if(applicantList.size() > 0){

						while(it.hasNext()) {
							appBean = (ApplicantBean) it.next();
							System.out.println("Applicant Name: " + appBean.getFullName());
							System.out.println("Scheduled Program Name: " + appBean.getProgramName());
							System.out.println("Applicant Status: "  +appBean.getStatus());

							if(appBean.getInterviewDate() != null){
								System.out.println("Interview Date: " + appBean.getInterviewDate());
							}
							else{
								System.out.println("Interview Date: " + appBean.getIdate());
							}

						}
						System.out.println("********************************");

						if(appBean.getStatus().equals("applied") || appBean.getStatus().equals("Applied")){
							updateApplicantSatus("Accepted",appId, appBean.getInterviewDate());
						}
						else if(appBean.getStatus().equals("Accepted") || appBean.getStatus().equals("accepted")){	
							updateApplicantSatus("Confirmed",appId, appBean.getInterviewDate());
						}
						else{
							message("Pleased to help you");
						}
					}
					else{
						message("No applicant exists!");
					}

				}
			}
			else{
				message("No Applicant Exist!" );
			}
		}
		catch (UniversityException e) {
			message(e.getMessage());
		}

	}

	private static boolean getAllApplicant() {
		List<ApplicantBean> applist = new ArrayList<>();
		int count = 0;
		try {

			applist = uasSer.getAllApplicant();

			if(applist.size() > 0){
				message("Aplicant Details");

				System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
				System.out.printf("%13s %20s %20s %20s %20s %20s %20s %20s %20s %30s","APPLICANT-ID", "APPLICANT-NAME","DATE_OF_BIRTH","HIGHEST_QUALIFICATION","MARKS_OBTAINED","GOALS","EMAIL_ID", "PROGRAM-NAME", "STATUS", "INTERVIEW-DATE");
				System.out.println();
				System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

				for(ApplicantBean ab : applist){

					System.out.format("%13d %20s %20s %20s %20f %20s %20s %20s %20s",ab.getAppId(), ab.getFullName(),ab.getDateOfBirth(),ab.getQualification(),ab.getMarks(),ab.getGoals(), ab.getEmail(), ab.getProgramName(),ab.getStatus());
					if(ab.getInterviewDate() != null){
						System.out.format("%30s",ab.getInterviewDate());
					}
					else{
						System.out.format("%30s",ab.getIdate());
					}
					System.out.println();

				}

				return true;
			}

		}
		catch (UniversityException e) {
			message(e.getMessage());
		}

		return false;
	}

	private static void updateApplicantSatus(String status, String appId, LocalDate dit) {

		if(status.equals("Confirmed")){
			//check interview date should be lesser than todays date
			if(LocalDate.now() != dit) {
				message("Applicant is yet to appear for interview on " + dit);
			}
			else {
				System.out.println("***************************************************");
				System.out.println("Do you wish to update the status of applicant as "+ status + "?");
				System.out.println("Y/N");
				String ans = sc.next();

				if(ans.equals("Y") || ans.equals("y")){
					try {
						int updated = uasSer.updateApplicationDetails(Integer.valueOf(appId), status, dit);
						message("You have successfully updated the status!");
					}
					catch (UniversityException e) {
						message(e.getMessage());
					}
				}
				else if(ans.equals("N") || ans.equals("n")){
					rejectApplicant(Integer.valueOf(appId));
				}
				else{
					message("Invalid Input!");
				}
			}
		}
		else{//Accepted
			System.out.println("Do you wish to update the status of applicant as "+ status + "?");
			System.out.println("Y/N");
			String ans = sc.next();

			if(ans.equals("Y") || ans.equals("y")){
				try {
					System.out.println("*************************************************");
					System.out.println("Enter date of interview in format yyyy-mm-dd");
					String date = sc.next();
					LocalDate interview_date = LocalDate.parse(date);

					if(uasSer.validateDate(interview_date)){
						int updated = uasSer.updateApplicationDetails(Integer.valueOf(appId), status, interview_date);
						System.out.println("You have successfully updated the status!");
					}
					else {
						message("Interview date should be greater than todays date.");
					}

				}
				catch (UniversityException e) {
					message(e.getMessage());
				}
			}
			else if(ans.equals("N") || ans.equals("n")){
				rejectApplicant(Integer.valueOf(appId));
			}
			else{
				message("Invalid Input!");
			}
		}
	}

	private static void rejectApplicant(int id) {
		System.out.println("Do you wish to reject the applicant?");
		System.out.println("Y/N");
		String ch = sc.next();
		switch (ch) {
		case "Y":
			rejected(id);
			break;
		case "N":
			message("No action performed!");
			break;
		case "y":
			rejected(id);
			break;
		case "n":
			message("No action performed!");
			break;
		default:message("Invalid Input!");
		break;
		}

	}

	private static void rejected(int id) {
		try {
			int updated = uasSer.updateApplicationDetails(id, "Rejected", LocalDate.now());
			message("You have successfully rejected the applicant!");
		}
		catch (UniversityException e) {

			message(e.getMessage());
		}
	}

	private static void admin(String user) {
		System.out.println("*********************************");
		System.out.println("Enter Login Id:");
		String loginId = sc.next();
		System.out.println("Enter Password: ");
		String password = sc.next();

		try {

			if(uasSer.isString(loginId) && uasSer.isString(password)) {


				if(uasSer.validateUser(loginId, password, user)) {

					while(true) {

						int option=0;
						System.out.println("*********************************");
						System.out.println("1. Add Programs Offered");
						System.out.println("2. Update Programs Offered");
						System.out.println("3. Delete Programs Offered");

						System.out.println("4. Add Programs Scheduled");
						System.out.println("5. View Programs Scheduled");
						System.out.println("6. Delete Programs Scheduled");
						System.out.println("7. Main Menu");
						System.out.println("8. Exit");

						message("Enter your choice");
						option = sc.nextInt();

						switch(option)
						{
						case 1: addProgramsOffered();
						break;
						case 2: updateProgramsOffered();
						break;
						case 3: deleteProgramsOffered();
						break;

						case 4: addProgramsScheduled();
						break;
						case 5: viewProgramsScheduled();
						break;
						case 6: deleteProgramsScheduled();
						break;
						case 7: mainMenu();
						break;
						case 8: exit();
						break;
						default:message("Invalid Input");
						break;
						}

					}
				}
				else {
					message("Incorrect Credentials");
				}
			}

		}
		catch (UniversityException e) {
			message(e.getMessage());
		}

	}

	private static void viewProgramsScheduled() {

		message("Program Scheduled");
		List<ProgramsScheduled>  progList = new ArrayList<>();

		try {

			progList = uasSer.getProgramsScheduled();

			if(progList.size() > 0) {
				System.out.println("-------------------------------------------------------------------------------------------------------------------");
				System.out.printf("%13s %13s %20s %20s %20s %20s","PROGRAM-ID", "PROGRAM-NAME", "LOCATION", "START-DATE", "END-DATE", "SESSION-PER-WEEK");
				System.out.println();
				System.out.println("-------------------------------------------------------------------------------------------------------------------");

				for(ProgramsScheduled p: progList){

					System.out.format("%13s %13s %20s %20s %20s %20d",p.getProgramId(), p.getProgramName(),p.getLocation(),p.getStartDate(),p.getEndDate(),p.getSessionPerWeek());
					System.out.println();
				} 
			}
			else{
				message("No Programs Scheduled yet!");
			}

		}
		catch (UniversityException e) {
			message(e.getMessage());
		}
	}

	private static void addProgramsOffered() {

		if(viewProgramsOffered()) {
			addPO();	
		}
		else{		
			addPO();
		}
	}

	private static void addPO() {

		System.out.println("**************************************");
		System.out.println("Enter Program Name : ");
		String pname = sc.next();

		System.out.println("Enter Description : ");
		sc.nextLine();
		String pdesc = sc.nextLine();

		System.out.println("Enter the eligibilty in %(60 TO 100) : ");
		String pelig = sc.next();

		System.out.println("Enter the duration in Months: ");
		int pdur = sc.nextInt();

		System.out.println("Enter if the certificate "
				+ "is offered of the program : ");
		String pcert = sc.next();

		try
		{
			if(uasSer.isString(pname) && uasSer.isString(pdesc) && uasSer.isString(pcert) && uasSer.validateEligibility(Integer.valueOf(pelig))){


				ProgramsOffered adminBean = new ProgramsOffered();

				adminBean.setProgramName(pname);
				adminBean.setDescription(pdesc);
				adminBean.setEligibility(pelig);
				adminBean.setDuration(pdur);
				adminBean.setDegreeCertOffered(pcert);

				int dataAdded = uasSer.addProgramsOffered(adminBean);

				if (dataAdded == 1)
				{
					message("Program Inserted Successfully!");
				}
				else
				{
					message("Something went wrong!");
				}
			}
		}
		catch (UniversityException ue)
		{
			message(ue.getMessage());
		}

	}

	private static void updateProgramsOffered() {

		if(viewProgramsOffered()){
			update();
		}
		else{
			message("No Programs To Update!");
		}
	}

	private static void update() {

		System.out.println("**********************************************");
		System.out.println("Enter Program Name You Want To Update: ");
		String programname= sc.next();

		System.out.println("Enter Description : ");
		sc.nextLine();
		String programdesc = sc.nextLine();

		System.out.println("Enter the eligibilty in %(60 TO 100) : ");
		String programelig = sc.nextLine();

		System.out.println("Enter the duration in Months : ");
		int programdur = sc.nextInt();

		System.out.println("Enter if the certificate "
				+ "is offered of the program : ");
		String programcert = sc.next();

		try
		{
			if(uasSer.isString(programname) && uasSer.isString(programdesc) && uasSer.isInteger(String.valueOf(programdur)) && uasSer.isString(programcert) && uasSer.validateEligibility(Integer.valueOf(programelig))) {

				ProgramsOffered adminBean = new ProgramsOffered();

				adminBean.setProgramName(programname);
				adminBean.setDescription(programdesc);
				adminBean.setEligibility(programelig);
				adminBean.setDuration(programdur);
				adminBean.setDegreeCertOffered(programcert);

				int dataUpdated = uasSer.updateProgramsOffered(adminBean);

				if (dataUpdated == 1)
				{
					message("Programs Added into the Table");
				}
				else
				{
					message("Something went wrong!");
				}
			}
		}
		catch (UniversityException ue)
		{
			message(ue.getMessage());
		}

	}

	private static void deleteProgramsOffered() {
		if(viewProgramsOffered()){
			System.out.println("**********************************************");
			System.out.println("Enter your Program Name which is to be deleted");
			String admin=sc.next();

			try
			{
				if(uasSer.isString(admin)){

					int dataDeleted = uasSer.deleteProgramsOffered(admin);
					if(dataDeleted==1)
					{
						message("Program Offered deleted");
					}
					else
					{
						message("Program Name Is Not Present");
					}

				} 
			}
			catch (UniversityException e)
			{
				message(e.getMessage());
			}
		}
		else{
			message("No Programs Offered for deletion!");
		}


	}

	private static void addProgramsScheduled() {

		if(viewProgramsOffered()){
			addProg();
		}
	}

	private static boolean viewProgramsOffered() {
		try {
			List<ProgramsOffered> polist = uasSer.getProgramsOffered();
			if(polist.size() > 0){
				message("Programs Offered");
				System.out.println("-------------------------------------------------------------------------------------------------------------------");
				System.out.printf("%20s %20s %20s %20s %20s","PROGRAM-NAME", "DESCRIPTION", "ELIGIBILITY", "DURATION", "CERTIFICATE");
				System.out.println();
				System.out.println("-------------------------------------------------------------------------------------------------------------------");

				for(ProgramsOffered p: polist){

					System.out.format("%20s %20s %20s %20d %20s",p.getProgramName(),p.getDescription(),p.getEligibility(),p.getDuration(),p.getDegreeCertOffered());
					System.out.println();
				} 

				return true;
			}
			else{
				message("No Programs offered yet!");
			}
		}
		catch (UniversityException e1) {
			message(e1.getMessage());
		}
		return false;
	}

	private static void addProg() {

		System.out.println("****************************");
		System.out.println("Enter program name:");
		String pname = sc.next();
		System.out.println("Enter location:");
		String loc = sc.next();
		System.out.println("Enter start date in format yyyy-mm-dd:");
		String sdate = sc.next();
		System.out.println("Enter end date in format yyyy-mm-dd:");
		String edate = sc.next();
		System.out.println("Enter session per week:");
		int session = sc.nextInt();

		LocalDate startDate=LocalDate.parse(sdate);

		LocalDate endDate=LocalDate.parse(edate);

		ProgramsScheduled ps = new ProgramsScheduled(pname,loc,startDate,endDate,session);
		try {
			if(uasSer.isValid(ps)){
				int id1=uasSer.addProgramScheduled(ps);
				if(id1>0)
				{
					message("Program successfully added with program id "+ id1);
				}
			}
		}
		catch (UniversityException e) {
			message(e.getMessage());
		}
	}

	private static void deleteProgramsScheduled() {

		viewProgramsScheduled();

		System.out.println("*****************************");
		System.out.println("Enter Program Scheduled Id");
		int sid=sc.nextInt();
		ArrayList<ApplicantBean> applicantList = new ArrayList<ApplicantBean>();

		try
		{
			if(uasSer.isInteger(String.valueOf(sid))){


				applicantList = uasSer.getApplicants("scheduled_program_id", String.valueOf(sid));

				if(applicantList.size() <= 0){
					int dataDeleted = uasSer.deleteProgramScheduled(sid);
					if(dataDeleted==1)
					{
						message("Scheduled program deleted");
					}
					else
					{
						message("Program Id Not Present!");
					}
				}
				else{
					message("Applicant is registered to this program, so cannot perform this operation");
				}
			}
		} 
		catch (UniversityException e)
		{
			message(e.getMessage());
		}
	}

	private static void exit() {
		message("Thank You!");
		System.exit(1);
	}
}
