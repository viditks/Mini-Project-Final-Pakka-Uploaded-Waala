package com.cg.uas.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Pattern;

import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.bean.ProgramsOffered;
import com.cg.uas.bean.ProgramsScheduled;
import com.cg.uas.bean.Users;
import com.cg.uas.dao.UasDao;
import com.cg.uas.dao.UasDaoImpl;
import com.cg.uas.exception.UniversityException;

public class UasServiceImpl implements UasService{

	UasDao uasDao = null;
	Users users = null;
	public UasServiceImpl() {
		uasDao = new UasDaoImpl();
		users = new Users();
	}
	@Override
	public List<ProgramsScheduled> getProgramsScheduled() throws UniversityException {
		
		return uasDao.getProgramsScheduled();
	}
	@Override
	public int setNewApplicant(ApplicantBean app) throws UniversityException {
		
		return uasDao.setNewApplicant(app);
	}
	@Override
	public Users getUserCredentials(String user) throws UniversityException {
		
		return uasDao.getUserCredentials(user);
	}
	//validating mac credentials from db
	@Override
	public boolean validateUser(String id, String password, String user) throws UniversityException {
		
		users = uasDao.getUserCredentials(user);
		
		if(users.getLoginId().equals(id) && users.getPassword().equals(password)) {
			return true;
		}
		else {
			return false;
		}
		
	}
	
	@Override
	public ArrayList<ApplicantBean> getApplicants(String column,String progId) throws UniversityException {
		return uasDao.getApplicants(column, progId);
	}
	@Override
	public int updateApplicationDetails(int appId, String status, LocalDate date)
			throws UniversityException {
		
		return uasDao.updateApplicationDetails(appId, status, date);
	}
	@Override
	public boolean Status(String status) throws UniversityException {
		if(status.equals("applied") || status.equals("Applied")){
			return true;
		}
		else if(status.equals("accepted") || status.equals("Accepted")){
			return true;
		}
		return false;
	}
	/*
	 * Shweta
	 * 
	 */
	@Override
	public int addProgramScheduled(ProgramsScheduled ps)
			throws UniversityException {
		
		return uasDao.addProgramScheduled(ps);
	}
	@Override
	public int deleteProgramScheduled(int scheduledProgId)
			throws UniversityException {
		
		return uasDao.deleteProgramScheduled(scheduledProgId);
	}
	/*
	 * 
	 * vaibhav
	 */
	@Override
	public int addProgramsOffered(ProgramsOffered admin)
			throws UniversityException {
		
		return uasDao.addProgramsOffered(admin);
	}
	@Override
	public int updateProgramsOffered(ProgramsOffered admin)
			throws UniversityException {
		
		return uasDao.updateProgramsOffered(admin);
	}
	@Override
	public int deleteProgramsOffered(String id) throws UniversityException {
		
		return uasDao.deleteProgramsOffered(id);
	}
	@Override
	public List<ProgramsOffered> getProgramsOffered()
			throws UniversityException {
		
		return uasDao.getProgramsOffered();
	}
	@Override
	public boolean isValid(ProgramsScheduled prog) throws UniversityException {
		
		String pname = prog.getProgramName();
		String loc = prog.getLocation();
		LocalDate startdate=prog.getStartDate();
		LocalDate enddate=prog.getEndDate();
		int session = prog.getSessionPerWeek();
	
		String nameRegex = "^[\\p{L} .'-]+$";
		String locRegex = "^[\\p{L} .'-]+$";
		
		if( !Pattern.matches(nameRegex, pname) ) {
			throw new UniversityException("Program Name Should be in characters only.");
			
		}
		else if( !Pattern.matches(locRegex, loc)) {
			throw new UniversityException("Location Should Start be in characters only.");
		}
		else if( session<=0 || session>6 ) {
			throw new UniversityException("Please Enter A Valid Session");
		}
		else if(! startdate.isAfter(LocalDate.now()) ){
			throw new UniversityException("Start date should be greater than todays date");
		}
		else if(! enddate.isAfter(LocalDate.now())){
			throw new UniversityException("End date should be greater than todays date");
		}
		else if( enddate.isBefore(startdate)   || enddate.isEqual(startdate)){
			throw new UniversityException("End date should be greater than Start date");
		}
		
		else  
		{
			return true;
		}
	}
	@Override
	public boolean isValid(ApplicantBean app) throws UniversityException {
		String fname = app.getFullName();
		String qualify = app.getQualification();
		float marks= app.getMarks();
		String email=app.getEmail();
		LocalDate birthdate=app.getDateOfBirth();
		String goals=app.getGoals();
		
		
		String fnameRegex = "^[\\p{L} .'-]+$";
		String quaRegex = "^[\\p{L} .'-]+$";
		String goal= "^[\\p{L} .'-]+$";
		String mail="[A-Za-z0-9+_.-]+@(.+)$";
		
		
		if( !Pattern.matches(fnameRegex, fname) ) {
			throw new UniversityException("Applicant Name Should be in characters");
			
		}
		else if( !Pattern.matches(quaRegex, qualify)) {
			throw new UniversityException("Qualification Should be in characters");
		}
		else if( !Pattern.matches(goal, goals)) {
			throw new UniversityException("Goals Should be in characters");
		}
		else if( marks<0 && marks>100 ) {
			throw new UniversityException("Please Enter A Valid Marks");
		}
		if( !Pattern.matches(mail, email) ) {
			throw new UniversityException("Please Enter a Valid email id");
		}
		else if( !birthdate.isBefore(LocalDate.now()) && !birthdate.isEqual(LocalDate.now())){
			throw new UniversityException("Birth date should be lesser than todays date");
		}
		else  
		{
			return true;
		}
	}
	@Override
	public boolean isString(String value) throws UniversityException {
		String regex = "^[\\p{L} .'-]+$";
		if(Pattern.matches(regex, value)){
			return true;
		}
		throw new UniversityException("Input should be characters only");
	}
	@Override
	public boolean isInteger(String value) throws UniversityException {
		String regex="\\d+";
		{
			if(Pattern.matches(regex, value)){
				return true;
			}
			throw new UniversityException("Input should be Intger only");
		}
		
	}
	@Override
	public boolean validProgramId(List<ProgramsScheduled> progList, String pid) throws UniversityException {
		String progid[] = new String[progList.size()];
		int i=0;
		for(ProgramsScheduled p : progList){
			progid[i++] = p.getProgramId();
		}
		
		for(int j=0;j<progid.length;j++){
			if(pid.equals(progid[j])){
				return true;		
			}
		}
		throw new UniversityException("Please choose from above program id only");
	}
	@Override
	public List<ApplicantBean> getAllApplicant() throws UniversityException {
		
		return uasDao.getAllApplicant();
	}
	@Override
	public boolean validateDate(LocalDate date) throws UniversityException {
		if(date.isAfter(LocalDate.now())){
			return true;
		}
		else{
			throw new UniversityException("Interview date should be greater than todays date");

		}
	}
	@Override
	public boolean validateEligibility(int value) throws UniversityException {
		if(value >= 60 || value <= 100) {
			return true;
		}
		else{
			throw new UniversityException("Eligibility should be between 60 to 100");
		}
	}

}
