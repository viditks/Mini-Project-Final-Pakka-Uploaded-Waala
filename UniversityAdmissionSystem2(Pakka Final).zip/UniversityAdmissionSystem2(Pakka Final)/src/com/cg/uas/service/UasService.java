package com.cg.uas.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.bean.ProgramsOffered;
import com.cg.uas.bean.ProgramsScheduled;
import com.cg.uas.bean.Users;
import com.cg.uas.exception.UniversityException;

public interface UasService {

	public List<ProgramsScheduled> getProgramsScheduled() throws UniversityException;
	public List<ProgramsOffered> getProgramsOffered() throws UniversityException;
	public int setNewApplicant(ApplicantBean app) throws UniversityException;
	public Users getUserCredentials(String user) throws UniversityException;
	public ArrayList<ApplicantBean> getApplicants(String column,String progId) throws UniversityException;
	public List<ApplicantBean> getAllApplicant() throws UniversityException;
	public int updateApplicationDetails(int appId, String status, LocalDate date) throws UniversityException;
	/*
	 * Shweta
	 * 
	 */
	public int addProgramScheduled(ProgramsScheduled ps) throws UniversityException;
	public int deleteProgramScheduled(int scheduledProgId) throws UniversityException;
	/*
	 * Vaibhav
	 * 
	 */
	public int addProgramsOffered(ProgramsOffered admin) throws UniversityException;
	public int updateProgramsOffered(ProgramsOffered admin) throws UniversityException;
	public int deleteProgramsOffered(String id) throws UniversityException;

	
	public boolean validateUser(String id, String password, String role) throws UniversityException;
	public boolean Status(String status) throws UniversityException;
	public boolean isValid(ProgramsScheduled prog)throws UniversityException;
	public boolean isValid(ApplicantBean app)throws UniversityException;
	public boolean isString(String value)throws UniversityException;
	public boolean isInteger(String value)throws UniversityException;
	public boolean validateEligibility(int value)throws UniversityException;
	public boolean validateDate(LocalDate date)throws UniversityException;
	public boolean validProgramId(List<ProgramsScheduled> progList, String pid)throws UniversityException;
}
